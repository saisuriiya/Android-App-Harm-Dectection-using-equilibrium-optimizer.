import os
import joblib
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

# Ensure the models directory exists
os.makedirs('models', exist_ok=True)

# Generate dummy data (20 features)
X, y = make_classification(n_samples=1000, n_features=20, random_state=42)

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

### ✅ Train XGBoost Model ###
xgboost_model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
xgboost_model.fit(X_train, y_train)
joblib.dump(xgboost_model, 'models/xgboost_model.pkl')
print("✅ XGBoost model saved successfully!")

### ✅ Train LightGBM Model ###
lightgbm_model = lgb.LGBMClassifier()
lightgbm_model.fit(X_train, y_train)
joblib.dump(lightgbm_model, 'models/lightgbm_model.pkl')
print("✅ LightGBM model saved successfully!")

### ✅ Train Random Forest Model ###
random_forest_model = RandomForestClassifier(n_estimators=100, random_state=42)
random_forest_model.fit(X_train, y_train)
joblib.dump(random_forest_model, 'models/random_forest_model.pkl')
print("✅ Random Forest model saved successfully!")

### ✅ Train Bi-LSTM Model ###
# Reshape data for LSTM (samples, time steps, features)
X_train_lstm = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
X_test_lstm = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)

# Define LSTM model
bilstm_model = Sequential([
    LSTM(64, return_sequences=True, input_shape=(X_train.shape[1], 1)),
    Dropout(0.2),
    LSTM(32),
    Dropout(0.2),
    Dense(1, activation='sigmoid')
])

# Compile model
bilstm_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train the Bi-LSTM model
bilstm_model.fit(X_train_lstm, y_train, epochs=10, batch_size=32, validation_data=(X_test_lstm, y_test))

# Save the Bi-LSTM model in `.keras` format
bilstm_model.save("models/bilstm_model.keras")  # ✅ Correct format

print("✅ Bi-LSTM model saved successfully in .keras format!")
