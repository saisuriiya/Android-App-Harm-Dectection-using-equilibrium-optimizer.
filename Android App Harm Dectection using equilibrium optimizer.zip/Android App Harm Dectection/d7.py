from flask import Flask, render_template, request, jsonify
import os
import joblib
import numpy as np
import tensorflow as tf
import json
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
STATS_FILE = "scan_stats.json"

# Ensure necessary directories exist
os.makedirs('models', exist_ok=True)
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load or initialize scan statistics
def load_scan_stats():
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE, "r") as file:
            return json.load(file)
    return {"total_scans": 0, "total_malware": 0, "scans": []}

scan_stats = load_scan_stats()

def save_scan_stats():
    """Save scan statistics to JSON file."""
    with open(STATS_FILE, "w") as file:
        json.dump(scan_stats, file, indent=4)

# Define Keras Wrapper class for Bi-LSTM model
class KerasWrapper:
    def __init__(self, model_path):
        self.model_path = model_path
        self.model = tf.keras.models.load_model(model_path, compile=False)

    def predict_proba(self, X):
        preds = self.model.predict(X)
        return np.column_stack([1 - preds, preds])

# Load trained models with error handling
models = {}
model_paths = {
    'XGBoost': 'models/xgboost_model.pkl',
    'LightGBM': 'models/lightgbm_model.pkl',
    'Random Forest': 'models/random_forest_model.pkl',
    'Bi-LSTM': 'models/bilstm_model.keras'
}

for model_name, path in model_paths.items():
    try:
        if model_name == "Bi-LSTM":
            models[model_name] = KerasWrapper(path)
        else:
            models[model_name] = joblib.load(path)
    except (FileNotFoundError, AttributeError) as e:
        print(f"Warning: {model_name} model file not found or corrupted ({e}). Using dummy predictions.")
        models[model_name] = None

# Equilibrium Optimizer (EO) for feature optimization
def equilibrium_optimizer(features, max_iter=50, alpha=1.0, beta=1.5):
    """Simple Equilibrium Optimizer for feature selection"""
    num_features = features.shape[1]
    best_solution = np.random.rand(num_features)  # Initial solution
    best_fitness = np.sum(features * best_solution)  # Initial fitness

    for _ in range(max_iter):
        new_solution = best_solution + alpha * (np.random.rand(num_features) - 0.5)
        new_solution = np.clip(new_solution, 0, 1)  # Ensure values stay in range
        new_fitness = np.sum(features * new_solution)

        if new_fitness > best_fitness:
            best_fitness = new_fitness
            best_solution = new_solution
    
    return features * best_solution  # Return optimized features

# Dummy feature extraction function
def extract_features(apk_path):
    """ Simulate feature extraction from an APK file. """
    raw_features = np.random.rand(1, 20)
    optimized_features = equilibrium_optimizer(raw_features)
    return optimized_features

@app.route('/')
def index():
    return render_template('index6.html')

@app.route('/dashboard')
def dashboard():
    """ Return updated JSON stats for frontend. """
    return jsonify(scan_stats)

@app.route('/upload', methods=['POST'])
def upload_file():
    """ Handle APK upload and malware detection """
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)
    
    # Extract optimized features
    features = extract_features(file_path)
    features_2d = features.reshape(1, -1)
    features_3d = features.reshape(1, 20, 1)
    
    # Predict using all models
    predictions = {}
    for model_name, model in models.items():
        if model:
            try:
                if model_name == "Bi-LSTM":
                    prob = model.predict_proba(features_3d)[0][1]
                else:
                    prob = model.predict_proba(features_2d)[0][1]
                predictions[model_name] = float(prob)
            except AttributeError:
                pred = model.predict(features_2d)[0][0]
                predictions[model_name] = float(pred)
        else:
            predictions[model_name] = float(np.random.rand())

    avg_harmful = float(np.mean(list(predictions.values())) * 100)
    avg_not_harmful = 100 - avg_harmful
    verdict = "Harmful" if avg_harmful > avg_not_harmful else "Not Harmful"
    
    # Check if file already exists in scan history
    file_exists = False
    for scan in scan_stats['scans']:
        if scan['file'] == filename:
            scan['harmfulness'] = avg_harmful
            scan['not_harmfulness'] = avg_not_harmful
            scan['verdict'] = verdict
            scan['scan_count'] = scan.get('scan_count', 1) + 1  # Increment scan count
            file_exists = True
            break
    
    if not file_exists:
        scan_stats['total_scans'] += 1
        if verdict == "Harmful":
            scan_stats['total_malware'] += 1
        scan_stats['scans'].append({
            'file': filename,
            'harmfulness': avg_harmful,
            'not_harmfulness': avg_not_harmful,
            'verdict': verdict,
            'scan_count': 1  # Initialize scan count
        })
    else:
        scan_stats['total_scans'] += 1  # Increment total scan count for repeated scans
    
    save_scan_stats()
    
    return jsonify({
        'file': filename,
        'harmfulness': avg_harmful,
        'not_harmfulness': avg_not_harmful,
        'verdict': verdict,
        'model_predictions': predictions,
        'scan_count': next(scan['scan_count'] for scan in scan_stats['scans'] if scan['file'] == filename)
    })


if __name__ == '__main__':
    app.run(debug=True)
